/**
 * Copyright 2017 Google Inc. All Rights Reserved.
 *
 * Licensed under the Apache License, Version 2.0 (the "License");
 * you may not use this file except in compliance with the License.
 * You may obtain a copy of the License at
 *
 * http://www.apache.org/licenses/LICENSE-2.0
 *
 * Unless required by applicable law or agreed to in writing, software
 * distributed under the License is distributed on an "AS IS" BASIS,
 * WITHOUT WARRANTIES OR CONDITIONS OF ANY KIND, either express or implied.
 * See the License for the specific language governing permissions and
 * limitations under the License.
 */

package com.google.android.gms.location.sample.location;

import android.app.ActivityManager;
import android.app.Notification;
import android.app.NotificationChannel;
import android.app.NotificationManager;
import android.app.PendingIntent;
import android.app.Service;
import android.content.Context;
import android.content.Intent;
import android.content.res.Configuration;
import android.location.Location;
import android.os.Binder;
import android.os.Build;
import android.os.Handler;
import android.os.HandlerThread;
import android.os.IBinder;
import android.os.Looper;
import android.util.Log;

import com.android.location.R;
import com.google.android.gms.location.FusedLocationProviderClient;
import com.google.android.gms.location.LocationCallback;
import com.google.android.gms.location.LocationRequest;
import com.google.android.gms.location.LocationResult;
import com.google.android.gms.location.LocationServices;
import com.google.android.gms.tasks.OnCompleteListener;
import com.google.android.gms.tasks.Task;

import androidx.annotation.NonNull;
import androidx.core.app.NotificationCompat;
import androidx.localbroadcastmanager.content.LocalBroadcastManager;

import static com.android.location.BuildConfig.APPLICATION_ID;

//import static com.google.android.gms.location.sample.location.BuildConfig.APPLICATION_ID;


public class LocationUpdatesService extends Service {

    private static final String PACKAGE_NAME = APPLICATION_ID;

    private static final String TAG = LocationUpdatesService.class.getSimpleName();

    // The name of the channel for notifications.
    private static final String CHANNEL_ID = "channel_01";
    // The identifier for the notification displayed for the foreground service.
    private static final int NOTIFICATION_ID = 12345678;
    //
    private NotificationManager mNotificationManager;

    //
    static final String ACTION_BROADCAST = PACKAGE_NAME + ".broadcast";

    //
    static final String EXTRA_LOCATION = PACKAGE_NAME + ".location";

    // Notificationの開始済みフラグ
    private static final String EXTRA_STARTED_FROM_NOTIFICATION =
            PACKAGE_NAME + ".started_from_notification";

    private final IBinder mBinder = new LocalBinder();


    // 位置情報要求時の通知時間(ms)
    private static final long UPDATE_INTERVAL_IN_MILLISECONDS = 10000;
    // The fastest rate for active location updates. Updates will never be more frequent　than this value.
    private static final long FASTEST_UPDATE_INTERVAL_IN_MILLISECONDS = UPDATE_INTERVAL_IN_MILLISECONDS / 2;

    // 横画面となっているかフラグ
    private boolean mIsScreenLandscaped = false;

    /**
     * Contains parameters used by {@link com.google.android.gms.location.FusedLocationProviderApi}.
     */
    private LocationRequest mLocationRequest;

    /**
     * Provides access to the Fused Location Provider API.
     */
    private FusedLocationProviderClient mFusedLocationClient;

    /**
     * Callback for changes in location.
     */
    private LocationCallback mLocationCallback;

    private Handler mServiceHandler;
    /**
     * 現在の位置情報
     */
    private Location mLocation;


    public LocationUpdatesService() { }


    @Override
    public void onCreate() {
        SampleLogUtil.logDebug("in");

        // FusedLocationClientのインスタンス取得
        mFusedLocationClient = LocationServices.getFusedLocationProviderClient(this);

        // 位置情報の取得コールバッククラス。
        mLocationCallback = new LocationCallback() {
            @Override
            public void onLocationResult(LocationResult locationResult) {
                super.onLocationResult(locationResult);

                // (取得に成功した) 位置情報を更新する
                notifyLocation(locationResult.getLastLocation());
            }
        };

        // 取得したい位置情報のリクエストを生成する
        createLocationRequest();

        // (端末で最後に取得した) 位置情報を取得する
        getLastLocation();

        // ハンドラー作成
        HandlerThread handlerThread = new HandlerThread(TAG);
        handlerThread.start();
        mServiceHandler = new Handler(handlerThread.getLooper());
        mNotificationManager = (NotificationManager) getSystemService(NOTIFICATION_SERVICE);

        // デバイスがAndroid O以上の場合
        if (Build.VERSION.SDK_INT >= Build.VERSION_CODES.O) {
            CharSequence name = getString(R.string.app_name);
            // NotificationChannelを生成する
            NotificationChannel mChannel = new NotificationChannel(
                    CHANNEL_ID, name, NotificationManager.IMPORTANCE_DEFAULT);

            // Set the Notification Channel for the Notification Manager.
            mNotificationManager.createNotificationChannel(mChannel);
        }

    }

    @Override
    public int onStartCommand(Intent intent, int flags, int startId) {
        SampleLogUtil.logDebug("in");

        // Notificationの開始済みフラグを取得する
        boolean isStartedFromNotification = intent.getBooleanExtra(
                EXTRA_STARTED_FROM_NOTIFICATION, false);

        // Notificationが開始済みの場合
        if (isStartedFromNotification) {
            // 位置情報の取得要求を停止する
            removeLocationUpdates();
            // サービスを終了する
            stopSelf();
        }

        // Tells the system to not try to recreate the service after it has been killed.
        return START_NOT_STICKY;
    }

    /*
     * 画面回転をした場合に呼ばれ、以下のライフサイクルとなる
     * MainActivityの再生成（onDestroy() → onCreate()）
     * LocationUpdatesServiceの再生成（onUnbind() → onDestroy() → onCreate() → onBind()）
     *
     * 横画面でバックグラウンドへ遷移した場合
     * LocationUpdatesService（onUnbind() → onDestroy()）
     */
    @Override
    public void onConfigurationChanged(Configuration newConfig) {
        super.onConfigurationChanged(newConfig);
        SampleLogUtil.logDebug("in" + "newConfig : " + newConfig.orientation); //　縦：1、横：2

        //　横画面となったフラグを設定する(true)
        mIsScreenLandscaped = true;
    }

    // MainActivityがフォアグラウンドに来て、サービスにバインドした場合に呼ばれる
    @Override
    public IBinder onBind(Intent intent) {
        SampleLogUtil.logDebug("in");

        // Notificationを消去する
        stopForeground(true);
        // 横画面となったフラグを設定する(false)
        mIsScreenLandscaped = false;

        return mBinder;
    }

    // Called when a client (MainActivity in case of this sample) returns to the foreground
    // and binds once again with this service. The service should cease to be a foreground
    // service when that happens.
    @Override
    public void onRebind(Intent intent) {
        super.onRebind(intent);
        SampleLogUtil.logDebug("in");

        // Notificationを消去する
        stopForeground(true);
        // 横画面となったフラグを設定する(false)
        mIsScreenLandscaped = false;
    }

    // Activityがバックグラウンドへ遷移した場合、呼ばれる
    @Override
    public boolean onUnbind(Intent intent) {
        SampleLogUtil.logDebug("in");

        // 位置情報取得要求中の場合、バックグラウンドへ遷移した処理を以下とする
        //　・縦画面表示の場合は、位置情報取得は継続してNotification表示を開始する。　
        // ・横画面表示の場合は、位置情報取得は停止してNotification表示はしない。
        if (!mIsScreenLandscaped && Utils.requestingLocationUpdates(this)) {
            SampleLogUtil.logDebug("Starting Notification");

            // Notificationを設定する
            Notification notification = setNotification();
            // Notificationの表示開始する
            startForeground(NOTIFICATION_ID, notification);
        }

        // Ensures onRebind() is called when a client re-binds.
        return true;
    }

    // Activityがバックグラウンドへ遷移した場合、呼ばれる
    @Override
    public void onDestroy() {
        SampleLogUtil.logDebug("in");

        mServiceHandler.removeCallbacksAndMessages(null);
    }


    /**
     * 位置情報の取得要求をする
     * {@link SecurityException}.
     */
    public void requestLocationUpdates() {
        Log.i(TAG, "Requesting location updates");

        // 位置情報要求中フラグを設定する(true)
        Utils.setRequestingLocationUpdates(this, true);

        // サービスの開始 (大体のケースで、onStartCommand()が呼ばれるかな？)
        Intent locationIntent = new Intent(getApplicationContext(), LocationUpdatesService.class);
        startService(locationIntent);

        try {
            // (FusedLocationClientに対して) 位置情報の取得要求をする
            mFusedLocationClient.requestLocationUpdates(
                    mLocationRequest,   // リクエスト内容
                    mLocationCallback,  // 位置情報取得コールバックの登録
                    Looper.myLooper());

        } catch (SecurityException unlikely) {
            Log.e(TAG, "Lost location permission. Could not request updates. " + unlikely);

            // (不揮発領域へ)位置情報要求中フラグを保存する(false)
            Utils.setRequestingLocationUpdates(this, false);
        }
    }

    /**
     * 位置情報の取得要求を停止する
     */
    public void removeLocationUpdates() {
        SampleLogUtil.logDebug("in");

        try {
            // 位置情報の取得要求を停止する
            mFusedLocationClient.removeLocationUpdates(mLocationCallback);
            // フラグのリクエスト済みを削除する
            Utils.setRequestingLocationUpdates(this, false);
            stopSelf();
        } catch (SecurityException unlikely) {
            Log.e(TAG, "Lost location permission. Could not remove updates. " + unlikely);

            // (不揮発領域へ)位置情報要求中フラグを保存する(true)
            Utils.setRequestingLocationUpdates(this, true);
        }
    }


    /**
     * Notificationの設定をする
     */
    private Notification setNotification() {

        // 取得した位置情報をテキスト設定する
        CharSequence locationText = Utils.getLocationText(mLocation);

        Intent intent = new Intent(this, LocationUpdatesService.class);
        // Notificationの開始済みフラグを設定する(true)
        intent.putExtra(EXTRA_STARTED_FROM_NOTIFICATION, true);

        // The PendingIntent that leads to a call to onStartCommand() in this service.
        PendingIntent servicePendingIntent = PendingIntent.getService(
                this, 0, intent, PendingIntent.FLAG_UPDATE_CURRENT);

        // The PendingIntent to launch activity.
        PendingIntent activityPendingIntent = PendingIntent.getActivity(this, 0,
                new Intent(this, MainActivity.class), 0);

        // Notificationの設定
        NotificationCompat.Builder builder = new NotificationCompat.Builder(this)
                .addAction(R.drawable.ic_launch, getString(R.string.launch_activity), // Notificationのボタン1
                        activityPendingIntent)
                .addAction(R.drawable.ic_cancel, getString(R.string.remove_location_updates), // Notificationのボタン2
                        servicePendingIntent)
                .setContentText(locationText) // 取得した位置情報を設定
                .setContentTitle(Utils.getLocationTitle(this))
                .setOngoing(true)             // 取得した位置情報を設定
                .setPriority(Notification.PRIORITY_HIGH)
                .setSmallIcon(R.mipmap.ic_launcher)
                .setTicker(locationText)
                .setWhen(System.currentTimeMillis());

        // Android O以上の場合、NotificationへチャンネルIDを設定
        if (Build.VERSION.SDK_INT >= Build.VERSION_CODES.O) {
            builder.setChannelId(CHANNEL_ID);
        }

        return builder.build();
    }

    // (端末で最後に取得した)位置情報を取得する
    private void getLastLocation() {
        try {
            mFusedLocationClient.getLastLocation()
                    .addOnCompleteListener(new OnCompleteListener<Location>() {
                        @Override
                        public void onComplete(@NonNull Task<Location> task) {
                            if (task.isSuccessful() && task.getResult() != null) {

                                // 取得したLocationを保持する
                                mLocation = task.getResult();
                            } else {
                                Log.w(TAG, "Failed to get location.");
                            }
                        }
                    });
        } catch (SecurityException unlikely) {
            Log.e(TAG, "Lost location permission." + unlikely);
        }
    }

    // (取得に成功した) 位置情報を各所へ送信する
    private void notifyLocation(Location location) {
        Log.i(TAG, "位置情報: " + location);

        // 取得したLocationを保持する
        mLocation = location;

        // (取得に成功した) 位置情報をブロードキャスト配信する
        Intent intent = new Intent(ACTION_BROADCAST);
        intent.putExtra(EXTRA_LOCATION, location);
        LocalBroadcastManager.getInstance(getApplicationContext()).sendBroadcast(intent);

        // 本サービスがフォアグラウンドサービスの場合のみ
        if (isServiceRunningInForeground(this)) {

            // 位置情報をNotificationへ表示更新する
            mNotificationManager.notify(NOTIFICATION_ID, setNotification());
        }
    }

    /**
     * 位置情報リクエストを生成する
     */
    private void createLocationRequest() {
        // リクエストインスタンスの生成
        mLocationRequest = new LocationRequest();

        // 位置情報要求時の通知時間(ms)
        mLocationRequest.setInterval(UPDATE_INTERVAL_IN_MILLISECONDS);
        // 位置情報要求時の通知間隔(m)
        mLocationRequest.setFastestInterval(FASTEST_UPDATE_INTERVAL_IN_MILLISECONDS);
        // 位置情報要求時の通知精度
        mLocationRequest.setPriority(LocationRequest.PRIORITY_HIGH_ACCURACY);

    }


    /**
     * Class used for the client Binder.  Since this service runs in the same process as its
     * clients, we don't need to deal with IPC.
     */
    public class LocalBinder extends Binder {
        LocationUpdatesService getService() {
            return LocationUpdatesService.this;
        }
    }

    /**
     * 本サービスがフォアグラウンドサービスかを判定する
     *
     * @param context The {@link Context}.
     */
    public boolean isServiceRunningInForeground(Context context) {
        ActivityManager manager = (ActivityManager) context.getSystemService(Context.ACTIVITY_SERVICE);
        for (ActivityManager.RunningServiceInfo service : manager.getRunningServices(Integer.MAX_VALUE)) {
            if (getClass().getName().equals(service.service.getClassName())) {
                if (service.foreground) {
                    return true;
                }
            }
        }
        return false;
    }
}
